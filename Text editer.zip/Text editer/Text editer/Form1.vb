﻿Option Strict On
Imports System.IO
'Name: Mike Cusson
'Date: 2019-07-26
'Program name: Text editor
'Description: The purpose of this program is to make and manipulate files.
'It's meant to be a text editor that can open and save text files.

Public Class frmTextEditor
    Private Sub btnOpen_Click(sender As Object, e As EventArgs) Handles btnOpen.Click
        ' For opening files
        Dim openFile As New OpenFileDialog
        Dim fileExt As String
        openFile.ShowDialog()
        fileExt = openFile.FileName

        'Trys to open specific path
        Try
            Dim streamReader As New StreamReader(fileExt)

            RichTextBox1.Text = streamReader.ReadToEnd()
            streamReader.Close()
            'If no path is given
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    'Save 
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim saveExt As String
        saveExt = SaveFile.FileName
        'This just makes it so if the file does not have a name, it won't save until you give it one.
        Try
            Dim streamWriter As New StreamWriter(saveExt)
            streamWriter.Write(RichTextBox1)
            streamWriter.Close()
        Catch
            If SaveFile.ShowDialog = Windows.Forms.DialogResult.OK Then

                Try
                    RichTextBox1.SaveFile(SaveFile.FileName,
                    RichTextBoxStreamType.PlainText)
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                End Try
            End If
        End Try



    End Sub
    'Exit the program
    Private Sub Exit_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        RichTextBox1.Clear()

    End Sub

    'Will copy the selected text to the clipboard. Gives error dialogue if nothing is selected
    Private Sub btnCopy_Click(sender As Object, e As EventArgs) Handles btnCopy.Click
        If RichTextBox1.SelectedText <> "" Then
            Clipboard.SetText(RichTextBox1.SelectedText)
        Else
            MsgBox("No text is selected to copy")
        End If
    End Sub

    'Will cut the selected text to the clipboard. Gives error dialogue if nothing is selected
    Private Sub btnCut_Click(sender As Object, e As EventArgs) Handles btnCut.Click
        If RichTextBox1.SelectedText <> "" Then
            Clipboard.SetText(RichTextBox1.SelectedText)
            RichTextBox1.SelectedText = ""
        Else
            MsgBox("No text is selected to cut")
        End If
    End Sub
    'Will paste the selected text from the clipboard.
    Private Sub btnPaste_Click(sender As Object, e As EventArgs) Handles btnPaste.Click

        Dim clip As IDataObject = Clipboard.GetDataObject()
        If clip.GetDataPresent(DataFormats.Text) Then
            RichTextBox1.SelectedText = CType(clip.GetData(DataFormats.Text), String)
        Else
            MsgBox("Data in the clipboard is not availble for entry into a textbox")
        End If
    End Sub

    'The msgbox displays the "about
    Private Sub btnAssist(sender As Object, e As EventArgs) Handles btnHelp.Click
        MsgBox("NETD-2202" + vbCrLf + vbCrLf + "Lab# 5" + vbCrLf + vbCrLf + "Mike Cusson")
    End Sub

    'Pretty much the same as the last save one
    Private Sub btnSaveAs_Click(sender As Object, e As EventArgs) Handles btnSaveAs.Click
        If SaveFile.ShowDialog = Windows.Forms.DialogResult.OK Then

            Try
                RichTextBox1.SaveFile(SaveFile.FileName,
                RichTextBoxStreamType.PlainText)
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub

    'Exit the program
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()

    End Sub
End Class

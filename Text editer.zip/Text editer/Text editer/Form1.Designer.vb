﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTextEditor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTextEditor))
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btnFile = New System.Windows.Forms.ToolStripDropDownButton()
        Me.btnNew = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnOpen = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnSave = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnSaveAs = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnEdit = New System.Windows.Forms.ToolStripDropDownButton()
        Me.btnCopy = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnCut = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnPaste = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnHelp = New System.Windows.Forms.ToolStripButton()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.SaveFile = New System.Windows.Forms.SaveFileDialog()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnFile, Me.btnEdit, Me.btnHelp})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(800, 25)
        Me.ToolStrip1.TabIndex = 0
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btnFile
        '
        Me.btnFile.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnNew, Me.btnOpen, Me.btnSave, Me.btnSaveAs, Me.btnExit})
        Me.btnFile.Image = CType(resources.GetObject("btnFile.Image"), System.Drawing.Image)
        Me.btnFile.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnFile.Name = "btnFile"
        Me.btnFile.Size = New System.Drawing.Size(38, 22)
        Me.btnFile.Text = "File"
        Me.btnFile.ToolTipText = "File "
        '
        'btnNew
        '
        Me.btnNew.Name = "btnNew"
        Me.btnNew.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.btnNew.Size = New System.Drawing.Size(180, 22)
        Me.btnNew.Text = "New"
        Me.btnNew.ToolTipText = "Creates a new file"
        '
        'btnOpen
        '
        Me.btnOpen.Name = "btnOpen"
        Me.btnOpen.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.btnOpen.Size = New System.Drawing.Size(180, 22)
        Me.btnOpen.Text = "Open"
        Me.btnOpen.ToolTipText = "Opens a text file"
        '
        'btnSave
        '
        Me.btnSave.Name = "btnSave"
        Me.btnSave.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.btnSave.Size = New System.Drawing.Size(180, 22)
        Me.btnSave.Text = "Save"
        Me.btnSave.ToolTipText = "Saves your current file"
        '
        'btnSaveAs
        '
        Me.btnSaveAs.Name = "btnSaveAs"
        Me.btnSaveAs.Size = New System.Drawing.Size(180, 22)
        Me.btnSaveAs.Text = "Save As"
        Me.btnSaveAs.ToolTipText = "Saves your current file as a name"
        '
        'btnExit
        '
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(180, 22)
        Me.btnExit.Text = "Exit"
        Me.btnExit.ToolTipText = "Exit the program"
        '
        'btnEdit
        '
        Me.btnEdit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnEdit.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnCopy, Me.btnCut, Me.btnPaste})
        Me.btnEdit.Image = CType(resources.GetObject("btnEdit.Image"), System.Drawing.Image)
        Me.btnEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(40, 22)
        Me.btnEdit.Text = "Edit"
        '
        'btnCopy
        '
        Me.btnCopy.Name = "btnCopy"
        Me.btnCopy.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.btnCopy.Size = New System.Drawing.Size(180, 22)
        Me.btnCopy.Text = "Copy"
        Me.btnCopy.ToolTipText = "Copy to clipboard"
        '
        'btnCut
        '
        Me.btnCut.Name = "btnCut"
        Me.btnCut.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.btnCut.Size = New System.Drawing.Size(180, 22)
        Me.btnCut.Text = "Cut"
        Me.btnCut.ToolTipText = "Cuts to clipboard"
        '
        'btnPaste
        '
        Me.btnPaste.Name = "btnPaste"
        Me.btnPaste.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.btnPaste.Size = New System.Drawing.Size(180, 22)
        Me.btnPaste.Text = "Paste"
        Me.btnPaste.ToolTipText = "Paste from clipboard"
        '
        'btnHelp
        '
        Me.btnHelp.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnHelp.Image = CType(resources.GetObject("btnHelp.Image"), System.Drawing.Image)
        Me.btnHelp.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(36, 22)
        Me.btnHelp.Text = "Help"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RichTextBox1.Location = New System.Drawing.Point(0, 25)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(800, 425)
        Me.RichTextBox1.TabIndex = 1
        Me.RichTextBox1.Text = ""
        '
        'SaveFile
        '
        Me.SaveFile.Filter = "TXT Files (*.txt*)|*.txt"
        Me.SaveFile.Title = "Save"
        '
        'ToolTip1
        '
        Me.ToolTip1.ToolTipTitle = "Input yout text here."
        '
        'frmTextEditor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Name = "frmTextEditor"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Mikerosoft Word"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents btnFile As ToolStripDropDownButton
    Friend WithEvents btnOpen As ToolStripMenuItem
    Friend WithEvents btnSave As ToolStripMenuItem
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents btnNew As ToolStripMenuItem
    Friend WithEvents btnEdit As ToolStripDropDownButton
    Friend WithEvents btnCopy As ToolStripMenuItem
    Friend WithEvents btnCut As ToolStripMenuItem
    Friend WithEvents btnPaste As ToolStripMenuItem
    Friend WithEvents btnHelp As ToolStripButton
    Friend WithEvents btnSaveAs As ToolStripMenuItem
    Friend WithEvents SaveFile As SaveFileDialog
    Friend WithEvents btnExit As ToolStripMenuItem
    Friend WithEvents ToolTip1 As ToolTip
End Class
